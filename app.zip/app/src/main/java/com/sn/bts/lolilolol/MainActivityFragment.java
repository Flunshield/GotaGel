package com.sn.bts.lolilolol;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;




public class MainActivityFragment extends AppCompatActivity {

    EditText ndc;
    EditText mdp;
    Button connect;
    private static final String TAG = "MyActivity";

    private static final int PERMS_REQUEST_CODE = 123;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_fragment);

         connect = (Button) findViewById(R.id.connect);


        connect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (hasPermission()){
                    Log.i(TAG, "permission ok");
                    // l'application a les permission
                    makeFolder();
                }
                else {
                    //L'application na pas les permissions
                    requestPerms();
                }
            }
        });
    }

    private Boolean hasPermission(){
        int res = 0;


        String[] permissions = new String[]{Manifest.permission.INTERNET};

        for (String perms : permissions){
            res = checkCallingOrSelfPermission(perms);
            if (!(res == PackageManager.PERMISSION_GRANTED)){
                return false;
            }
        }
        return true;
    }

    private void requestPerms(){
        String[] permissions = new String[]{Manifest.permission.INTERNET};
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
            requestPermissions(permissions,PERMS_REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int [] grantResults){
        boolean allowed = true;

        switch (requestCode){
            case PERMS_REQUEST_CODE:

                for (int res : grantResults){
                    // if user granted all permissions
                    allowed = allowed && (res == PackageManager.PERMISSION_GRANTED);
                }

                break;
            default:
                // if user not granted permissions
                allowed = false;
                break; 
        }

        if (allowed){
            //user granted all permissions we can perform our task.
            makeFolder();
        }
        else {
            // we wive give warning to user that they haven't granted permissions.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if(shouldShowRequestPermissionRationale(Manifest.permission.INTERNET)){
                    Toast.makeText(this, "Internet Permission denied.", Toast.LENGTH_SHORT).show();

                }
            }
        }
    }

    public void makeFolder(){
        ndc = (EditText) findViewById(R.id.ndc);
        mdp = (EditText) findViewById(R.id.mdp);
       final String username = ndc.getText().toString();
       final String password = mdp.getText().toString();
        Log.i(TAG, "Valeur récupérer");
        Response.Listener<String> responseListener = new Response.Listener<String>(){
            @Override
            public void onResponse(String response) {
                try {
                    Log.i(TAG, "Début try");
                    response = response.replace("<br>", " ");
                    response = response.replace("<br", " ");
                    response = response.replace("<html>", " ");
                    response = response.replace("</html>", " ");
                    response = response.replace("<b>Warning</b>:  mysqli_connect(): (HY000/1045): Access denied for user 'Name'@'2a00:b6e0:1:20:2::1' (using password: YES) in <b>/home/julien84350/www/login.php</b> on line <b>6</b>  />", " ");
                    Log.i(TAG, "Replace");
                    JSONObject jsonResponse = new JSONObject(response);

                    Log.i(TAG, "1try");
                    int success = jsonResponse.getInt("success");

                    Log.i(TAG, "2try");

                    if (success == 0){
                        Log.i(TAG, "connexion failled");
                        Toast.makeText(getApplicationContext(), "Mauvais nom de compte et/ou mot de passe", Toast.LENGTH_LONG).show();
                    }

                    if (success == 1){
                        Log.i(TAG, "Succes connexion");
                        Toast.makeText(getApplicationContext(), "Identifiant ok", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(MainActivityFragment.this, UserAreaActivity.class);
                        MainActivityFragment.this.startActivity(intent);

                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };
        Log.i(TAG, "1");
        LoginRequest loginRequest = new LoginRequest(username, password, responseListener);
        Log.i(TAG, "2");
        RequestQueue queue = Volley.newRequestQueue(MainActivityFragment.this);
        Log.i(TAG, "3");
        queue.add(loginRequest);
        Log.i(TAG, "4");



    }
}
